package com.qa.am.Amazon;

public class OrderHistory {

}
