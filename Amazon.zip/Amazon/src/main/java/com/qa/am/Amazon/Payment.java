package com.qa.am.Amazon;

public class Payment implements CardPayment {


}
