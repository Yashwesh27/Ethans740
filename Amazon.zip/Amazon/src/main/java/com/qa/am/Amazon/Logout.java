package com.qa.am.Amazon;

public class Logout extends BasePage{

}
