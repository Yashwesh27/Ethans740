package com.qa.am.Amazon;

public interface CardPayment {

	

}
